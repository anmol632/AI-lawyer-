import { useState } from "react";

export default function Demo() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (input.trim()) {
      setMessages([...messages, { fromUser: true, text: input }, { fromUser: false, text: "This is a demo response." }]);
      setInput("");
    }
  };

  return (
    <section className="p-8">
      <h2 className="text-2xl font-bold mb-4">Chat with AI Lawyer</h2>
      <div className="border p-4 rounded h-64 overflow-y-auto bg-gray-100 mb-4">
        {messages.map((msg, i) => (
          <div key={i} className={msg.fromUser ? "text-right text-blue-600" : "text-left text-gray-800"}>
            <p>{msg.text}</p>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input className="flex-grow border p-2 rounded" value={input} onChange={e => setInput(e.target.value)} placeholder="Ask a legal question..." />
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={sendMessage}>Send</button>
      </div>
    </section>
  );
}