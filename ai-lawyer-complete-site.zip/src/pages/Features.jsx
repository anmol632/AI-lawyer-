export default function Features() {
  return (
    <section className="p-8">
      <h2 className="text-2xl font-bold mb-4">Key Features</h2>
      <ul className="list-disc pl-6 space-y-2">
        <li>Legal Research</li>
        <li>Case Analysis</li>
        <li>Instant Legal Advice</li>
      </ul>
    </section>
  );
}