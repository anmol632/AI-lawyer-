export default function Contact() {
  return (
    <section className="p-8">
      <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
      <form className="space-y-4 max-w-md mx-auto">
        <input className="w-full border p-2 rounded" placeholder="Your Name" />
        <input className="w-full border p-2 rounded" placeholder="Your Email" />
        <textarea className="w-full border p-2 rounded" placeholder="Your Message" rows="4" />
        <button className="bg-green-500 text-white px-4 py-2 rounded">Send Message</button>
      </form>
    </section>
  );
}